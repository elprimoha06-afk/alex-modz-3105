# ALEX MODZ (3106, v3.2.8)

Proyecto 3106 rebrandeado a ALEX MODZ (nombre visible).
Bundle ID, esquema de Xcode (3106) y extensiones de archivo (.3106 / .3105) no se cambiaron, para que el workflow siga funcionando.

## Cómo sacar el IPA (no se puede compilar en Linux, se necesita Mac/Xcode)

1. Sube este proyecto a un repositorio de GitHub (rama `main` o `3106`).
2. En GitHub: Actions -> "Build unsigned IPA" -> Run workflow.
3. El workflow usa macos-15 + xcodebuild y sube el artefacto `3106-unsigned-ipa` con el archivo `3106-3.2.8-unsigned.ipa`.
4. Descarga ese IPA y fírmalo / instálalo con tu método habitual (AltStore, TrollStore, etc.).

El nombre que verás en el iPhone es ALEX MODZ (CFBundleDisplayName).
